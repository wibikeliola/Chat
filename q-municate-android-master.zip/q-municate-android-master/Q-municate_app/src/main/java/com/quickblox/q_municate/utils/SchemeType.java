package com.quickblox.q_municate.utils;

public interface SchemeType {

    String SCHEME_CONTENT = "content";
    String SCHEME_CONTENT_GOOGLE = "content://com.google.android";
    String SCHEME_FILE = "file";
}