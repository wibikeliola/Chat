package com.quickblox.q_municate.utils.image;

public enum ImageSource {
    GALLERY,
    CAMERA
}