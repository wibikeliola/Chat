package com.quickblox.q_municate.utils.listeners;

public interface CounterChangedListener {

    void onCounterContactsChanged(int valueCounterContacts);
}