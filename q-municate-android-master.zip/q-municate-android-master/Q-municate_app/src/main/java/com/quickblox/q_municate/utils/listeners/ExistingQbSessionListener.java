package com.quickblox.q_municate.utils.listeners;

public interface ExistingQbSessionListener {

    void onStartSessionSuccess();

    void onStartSessionFail();
}