package com.quickblox.q_municate.utils.listeners;

public interface UserOperationListener {

    void onAddUserClicked(int userId);
}