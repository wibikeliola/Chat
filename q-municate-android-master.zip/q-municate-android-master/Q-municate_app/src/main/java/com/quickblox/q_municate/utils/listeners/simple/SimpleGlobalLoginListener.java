package com.quickblox.q_municate.utils.listeners.simple;

import com.quickblox.q_municate.utils.listeners.GlobalLoginListener;

public class SimpleGlobalLoginListener implements GlobalLoginListener {

    @Override
    public void onCompleteQbLogin() {

    }

    @Override
    public void onCompleteQbChatLogin() {

    }

    @Override
    public void onCompleteWithError(String error) {

    }
}