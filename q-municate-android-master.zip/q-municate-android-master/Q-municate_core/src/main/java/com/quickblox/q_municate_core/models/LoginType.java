package com.quickblox.q_municate_core.models;

public enum LoginType {
    EMAIL, FACEBOOK, FIREBASE_PHONE
}
