package com.quickblox.q_municate_core.utils;

/**
 * Created by roman on 8/15/17.
 */

public class MimeTypeAttach {
    public static final String IMAGE_MIME = "image/jpeg";
    public static final String AUDIO_MIME = "audio/mp4";
    public static final String VIDEO_MIME = "video/mpeg";
}
