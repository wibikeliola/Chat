package com.quickblox.q_municate_base_cache.model;


public interface QMBaseColumns {
    String ID = "id";
    String CREATED_AT = "created_at";
    String UPDATED_AT = "updated_at";
}
